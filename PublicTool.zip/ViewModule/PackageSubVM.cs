﻿using DragAndRun.Utils;
using SharpSvn;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Xml;

namespace DragAndRun.ViewModule
{
    class PackageSubVM : INotifyPropertyChanged
    {
        public PackageSubVM()
        {
        }
        #region  数据绑定
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = this.PropertyChanged;
            if (handler != null)
            {
                PropertyChangedEventArgs e = new PropertyChangedEventArgs(propertyName);
                handler(this, e);
            }
        }

        private static PackageSubVM _instance;
        public static PackageSubVM Instance 
        {
            get
            {
                if (_instance == null)
                    _instance = new PackageSubVM();
                return _instance;
            }
        }

        private Visibility _loadingPanel = System.Windows.Visibility.Hidden;
        public Visibility LoadingPanel
        {
            get { return _loadingPanel; }
            set
            {
                _loadingPanel = value;
                OnPropertyChanged("LoadingPanel");
            }
        }

        private bool _packageAndroid;
        public bool PackageAndroid
        {
            get { return _packageAndroid; }
            set { 
                _packageAndroid = value;
                GlobalVM.Instance.EncodeAndroid = value;
                OnPropertyChanged("PackageAndroid");
            }
        }
        
        private string _svnPath;
        public string SVNPath
        {
            get { return _svnPath; }
            set { _svnPath = value; OnPropertyChanged("SVNPath"); }
        }

        private string _beginVersion;
        public string BeginVersion
        {
            get { return _beginVersion; }
            set { _beginVersion = value; OnPropertyChanged("BeginVersion"); }
        }

        private string _endVersion;
        public string EndVersion
        {
            get { return _endVersion; }
            set { _endVersion = value; OnPropertyChanged("EndVersion"); }
        }

        private string _version;
        public string Version
        {
            get { return _version; }
            set { _version = value; OnPropertyChanged("Version"); }
        }

        private string _outPath;
        public string OutPath
        {
            get { return _outPath; }
            set { _outPath = value; OnPropertyChanged("OutPath"); }
        }

        private string _filter;
        public string Filter
        {
            get { return _filter; }
            set { _filter = value; OnPropertyChanged("Filter"); }
        }

        private bool _removeMEDebug;
        public bool RemoveMEDebug
        {
            get { return _removeMEDebug; }
            set { _removeMEDebug = value; OnPropertyChanged("RemoveMEDebug"); }
        }

        private bool _needReInstall;
        public bool NeedReInstall
        {
            get { return _needReInstall; }
            set { _needReInstall = value; OnPropertyChanged("NeedReInstall"); }
        }
        
        private string _reInstallURL;
        public string ReInstallURL
        {
            get { return _reInstallURL; }
            set { _reInstallURL = value; OnPropertyChanged("ReInstallURL"); }
        }
        
        private string _flushCDNUrl;
        public string FlushCDNUrl
        {
            get { return _flushCDNUrl; }
            set { _flushCDNUrl = value; OnPropertyChanged("FlushCDNUrl"); }
        }

        private string _uploadVersionUrl;
        public string UploadVersionUrl
        {
            get { return _uploadVersionUrl; }
            set { _uploadVersionUrl = value; OnPropertyChanged("UploadVersionUrl"); }
        }

        private string _description;
        public string Description
        {
            get { return _description; }
            set { 
                _description = value;
                OnPropertyChanged("Description"); 
            }
        }

        public void updateDescription(string str)
        {
            Description = Description + "\n" + str;
        }
        
        // 打开导出目录
        private ICommand _openOutPutPath;
        public ICommand OpenOutPutPath 
        { 
            get 
            {
                if (_openOutPutPath == null)
                    _openOutPutPath = new OpenOutPutPathCommand();
                return _openOutPutPath;
            }
            set { _openOutPutPath = value; }
        }

        private class OpenOutPutPathCommand : ICommand
        {
            public bool CanExecute(object parameter)
            {
                return true;
            }
            public event EventHandler CanExecuteChanged;
            public void Execute(object parameter)
            {
                Process.Start("explorer.exe", PackageSubVM.Instance.OutPath);
            }
        }

        // 上传文件到CDN
        private ICommand _uploadFileToCDN;
        public ICommand UploadFileToCDN
        {
            get
            {
                if (_uploadFileToCDN == null)
                    _uploadFileToCDN = new UploadFileToCDNCommand();
                return _uploadFileToCDN;
            }
            set { _uploadFileToCDN = value; }
        }

        private class UploadFileToCDNCommand : ICommand
        {
            public bool CanExecute(object parameter)
            {
                return true;
            }
            public event EventHandler CanExecuteChanged;
            public void Execute(object parameter)
            {
                if (PackageSubVM.Instance.szLastVersion == "")
                {
                    MessageBox.Show("没有生成版本文件.");
                    return;
                }
                FtpHelper ftp = new FtpHelper("113.107.167.229", "root", "#!9BVAPlDJ2%Nj@z");
                ftp.sftpUpload(PackageSubVM.Instance.OutPath + @"\versions", PackageSubVM.Instance.UploadVersionUrl + "/versions");
                string editionFileName = PackageSubVM.Instance.szLastVersion + "-" + PackageSubVM.Instance.Version;
                ftp.sftpUpload(PackageSubVM.Instance.szDifferentOutPath + @"\" + editionFileName + ".zip", PackageSubVM.Instance.UploadVersionUrl + String.Format("/edition/{0}.zip", editionFileName));
                ftp.sftpUpload(PackageSubVM.Instance.szDifferentOutPath + @"\" + editionFileName + ".xml", PackageSubVM.Instance.UploadVersionUrl + String.Format("/edition/{0}.xml", editionFileName));
            }
        }

        // 刷新CDN
        private ICommand _flushCDN;
        public ICommand FlushCDN
        {
            get
            {
                if (_flushCDN == null)
                    _flushCDN = new FlushCDNCommand();
                return _flushCDN;
            }
            set { _flushCDN = value; }
        }

        private string requestResult;
        private class FlushCDNCommand : ICommand
        {
            public bool CanExecute(object parameter)
            {
                return true;
            }
            public event EventHandler CanExecuteChanged;
            public void Execute(object parameter)
            {
                if (PackageSubVM.Instance.FlushCDNUrl != "")
                {
                    FtpHelper ftp = new FtpHelper();
                    PackageSubVM.Instance.requestResult = ftp.httpRequest("POST", PackageSubVM.Instance.FlushCDNUrl + "/versions", "");
                }
                else
                {
                    string url = "http://push.dnion.com/cdnUrlPush.do?captcha=436bd644&type=0&url=http://shenqu.cdn.feiliu.com/update/";
                    System.Diagnostics.Process.Start(url);
                }
            }
        }

        //检查CDN刷新结果
        private ICommand _checkFlushResult;
        public ICommand CheckFlushResult
        {
            get
            {
                if (_checkFlushResult == null)
                    _checkFlushResult = new CheckFlushResultCommand();
                return _checkFlushResult;
            }
            set { _checkFlushResult = value; }
        }

        private class CheckFlushResultCommand : ICommand
        {
            public bool CanExecute(object parameter)
            {
                return true;
            }
            public event EventHandler CanExecuteChanged;
            public void Execute(object parameter)
            {
                FtpHelper ftp = new FtpHelper();
                ftp.httpRequest("GET", "", PackageSubVM.Instance.requestResult);
            }
        }

        // 生成热更包
        private ICommand _generalUpdatePackage;
        public ICommand GeneralUpdatePackage
        {
            get
            {
                if (_generalUpdatePackage == null)
                    _generalUpdatePackage = new GeneralUpdatePackageCommand();
                return _generalUpdatePackage;
            }
            set { _generalUpdatePackage = value; }
        }

        private class GeneralUpdatePackageCommand : ICommand
        {
            public bool CanExecute(object parameter)
            {
                return true;
            }
            public event EventHandler CanExecuteChanged;
            public void Execute(object parameter)
            {
                if (PackageSubVM.Instance.BeginVersion == "" || PackageSubVM.Instance.EndVersion == "" || PackageSubVM.Instance.SVNPath == "")
                {
                    MessageBox.Show("SVN信息没填完整!");
                    return;
                }
                MainWindow window = (MainWindow)Application.Current.MainWindow;
                if (!window.checkProjectSelect())
                {
                    MessageBox.Show("请选着需要打包的项目");
                    return;
                }
                PackageSubVM.Instance.Description = "======================= 开始打热更包 =============================";
                //save data
                PackageSubVM.Instance.saveData();
                //run
                PackageSubVM.Instance.LoadingPanel = System.Windows.Visibility.Visible;
                window._logicThread = new Thread(delegate()
                {
                    window.Dispatcher.Invoke(new Action(delegate
                    {
                        PackageSubVM.Instance.genCurVersionXML();
                        window.Description.ScrollToEnd();
                        string preStr = "Android分包";
                        if (!PackageSubVM.Instance.PackageAndroid)
                        {
                            preStr = "IOS分包";
                        }
                        MessageBox.Show(preStr + "打包完成.");
                        PackageSubVM.Instance.LoadingPanel = System.Windows.Visibility.Hidden;
                        window._logicThread.Abort();
                    }));
                });
                window._logicThread.IsBackground = true;
                window._logicThread.Start();
            }
        }
        
        #endregion

        #region  界面数据初始化
        // 
        public void cleanData()
        {
            PackageSubVM.Instance.SVNPath = "";
            PackageSubVM.Instance.BeginVersion = "";
            PackageSubVM.Instance.EndVersion = "";
            PackageSubVM.Instance.PackageAndroid = SaveData.GetInstance().getData("szEncodeType") == "True";
        }

        public void saveData()
        {
            SaveData.GetInstance().setData("szOutPath", PackageSubVM.Instance.OutPath);
            SaveData.GetInstance().setData("szFilter", PackageSubVM.Instance.Filter);
            SaveData.GetInstance().setData("szPackageURL", PackageSubVM.Instance.ReInstallURL);
            SaveData.GetInstance().setData("szFlushCDNUrl", PackageSubVM.Instance.FlushCDNUrl);
            SaveData.GetInstance().setData("szUploadVersionUrl", PackageSubVM.Instance.FlushCDNUrl);
            SaveData.GetInstance().setData("szVersionPath", PackageSubVM.Instance.SVNPath);
            SaveData.GetInstance().setData("szBeginVersion", PackageSubVM.Instance.BeginVersion);
            SaveData.GetInstance().setData("szEndVersion", PackageSubVM.Instance.EndVersion);
            SaveData.GetInstance().setData("szEncodeType", PackageSubVM.Instance.PackageAndroid.ToString());
        }

        public void loadData(string configName)
        {
            SaveData.GetInstance().loadConfig(configName);
            PackageSubVM.Instance.OutPath = SaveData.GetInstance().getData("szOutPath");
            PackageSubVM.Instance.Filter = SaveData.GetInstance().getData("szFilter");
            PackageSubVM.Instance.ReInstallURL = SaveData.GetInstance().getData("szPackageURL");
            PackageSubVM.Instance.FlushCDNUrl = SaveData.GetInstance().getData("szFlushCDNUrl");
            PackageSubVM.Instance.UploadVersionUrl = SaveData.GetInstance().getData("szUploadVersionUrl");
            PackageSubVM.Instance.SVNPath = SaveData.GetInstance().getData("szVersionPath");
            PackageSubVM.Instance.BeginVersion = SaveData.GetInstance().getData("szBeginVersion");
            PackageSubVM.Instance.EndVersion = SaveData.GetInstance().getData("szEndVersion");
            PackageSubVM.Instance.PackageAndroid = SaveData.GetInstance().getData("szEncodeType") == "True";
        }
        #endregion

        #region ============================================ 热更包逻辑 =============================================
        public string szDifferentOutPath;
        public string szResourceOutPath;
        public string szUploadZipOutPath;
        public string szLastVersion = "";

        private void init()
        {
            szLastVersion = "";
            szDifferentOutPath = PackageSubVM.Instance.OutPath + @"\edition";
            if (!System.IO.Directory.Exists(szDifferentOutPath))
            {
                try
                {
                    System.IO.Directory.CreateDirectory(szDifferentOutPath);
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                    return;
                }
            }
            szResourceOutPath = PackageSubVM.Instance.OutPath + @"\source";
            if (!System.IO.Directory.Exists(szResourceOutPath))
            {
                try
                {
                    System.IO.Directory.CreateDirectory(szResourceOutPath);
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                    return;
                }
            }
        }

        public void genCurVersionXML()
        {
            init();

            // get update file
            XmlDocument editionXML = this.getSVNDifferFiles();
            // encode
            this.encodeResource();
            // add to zip
            this.zipOutPutResource();
            // save update file name
            editionXML.Save(szDifferentOutPath + @"\" + szLastVersion + "-" + PackageSubVM.Instance.Version + ".xml");
            // save to version file
            this.saveCurrentVersion();
        }

        //================================================ use svn ================================================
        //获取最大的版本号, 保存在szLastVersion
        public void getLastVersion()
        {
            if (System.IO.File.Exists(PackageSubVM.Instance.OutPath + @"\versions"))
            {
                StreamReader sr = new StreamReader(PackageSubVM.Instance.OutPath + @"\versions");
                while (sr.Peek() > 0)
                {
                    string line = sr.ReadLine();
                    int begin = line.IndexOf(":");
                    int end = line.IndexOf(",");
                    if (end == -1)
                    {
                        end = line.IndexOf(";");
                    }
                    string version = line.Substring(begin + 1, end - begin - 1);
                    if (version.CompareTo(szLastVersion) > 0 && version.CompareTo(PackageSubVM.Instance.Version) < 0)
                        szLastVersion = version;
                }
                sr.Close();
            }
            else
            {
                FileStream file = System.IO.File.Create(PackageSubVM.Instance.OutPath + @"\versions");
                file.Close();
            }
        }

        public XmlDocument getSVNDifferFiles()
        {
            //获取最大的版本号
            this.getLastVersion();
            // diff xml
            XmlDocument newDoc = new XmlDocument();
            XmlDeclaration xmldecl = newDoc.CreateXmlDeclaration("1.0", "UTF-8", null);
            newDoc.AppendChild(xmldecl);
            XmlElement newRoot = newDoc.CreateElement("files");
            newDoc.AppendChild(newRoot);
            newRoot.SetAttribute("version", PackageSubVM.Instance.Version);

            long fileSizes = 0;
            int index = 0;
            string[] szFilter = PackageSubVM.Instance.Filter.Split(new char[1] { ';' });
            SvnClient svnClient = new SvnClient();
            //List<SvnDiffSummaryEventArgs> list;
            System.Collections.ObjectModel.Collection<SvnDiffSummaryEventArgs> list;
            svnClient.GetDiffSummary(new SvnUriTarget(PackageSubVM.Instance.SVNPath, Int32.Parse(PackageSubVM.Instance.BeginVersion)), new SvnUriTarget(PackageSubVM.Instance.SVNPath, Int32.Parse(PackageSubVM.Instance.EndVersion)), out list);
            foreach (SvnDiffSummaryEventArgs item in list)
            {
                if (szFilter.Contains(Path.GetExtension(item.Path)) || szFilter.Contains(Path.GetFileName(item.Path)))
                {
                    continue;
                }

                string fullFileName = szResourceOutPath + "\\" + item.Path;
                if (item.NodeKind == SvnNodeKind.Directory)
                {
                    if (Directory.Exists(fullFileName) == false)
                    {
                        DirectoryInfo info = Directory.CreateDirectory(fullFileName);
                    }
                    continue;
                }

                string outPath = Path.GetDirectoryName(fullFileName);
                if (Directory.Exists(outPath) == false)
                {
                    DirectoryInfo info = Directory.CreateDirectory(outPath);
                }
                try
                {
                    SvnClient exportSVN = new SvnClient();
                    SvnExportArgs ex = new SvnExportArgs();
                    ex.Overwrite = true;
                    long size = 0;
                    if (item.DiffKind != SvnDiffKind.Deleted)
                    {
                        exportSVN.Export(new SvnUriTarget(item.ToUri, Int32.Parse(PackageSubVM.Instance.EndVersion)), fullFileName, ex);
                        index = index + 1;
                        this.createXmlNode(newDoc, newRoot, item.Path, this.createFileMD5(fullFileName, out size), "1", index);
                        fileSizes += size;
                    }
                    else
                    {
                        this.createXmlNode(newDoc, newRoot, item.Path, "this is a delete file.", "0", index);
                    }
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.Message);
                    Console.WriteLine(ee.Message);
                }
            }

            newRoot.SetAttribute("lastVersion", szLastVersion);
            newRoot.SetAttribute("size", fileSizes.ToString());
            return newDoc;
        }

        void createXmlNode(XmlDocument doc, XmlElement root, string fileName, string md5, string change, int index)
        {
            XmlElement node = doc.CreateElement("file_" + index);
            node.SetAttribute("fileName", fileName);
            node.SetAttribute("md5", md5);
            if (change != "")
            {
                node.SetAttribute("change", change);
            }
            root.AppendChild(node);
        }

        private string createFileMD5(string filePath, out long size)
        {
            FileStream file = new FileStream(filePath, FileMode.Open);
            MD5 md5 = MD5.Create();
            byte[] retVal = md5.ComputeHash(file);
            size = file.Length;
            file.Close();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < retVal.Length; i++)
            {
                sb.Append(retVal[i].ToString("x2"));
            }
            return sb.ToString();
        }

        private void encodeResource()
        {
            FileEncode.Instance.updateDescription("\n开始加密输出的资源");
            FileEncode.Instance.encodeLua(szResourceOutPath, szResourceOutPath);
            FileEncode.Instance.encodeImage(szResourceOutPath, szResourceOutPath);
            string preStr = "Android分包";
            if (!PackageSubVM.Instance.PackageAndroid)
            {
                preStr = "IOS分包";
            }
            FileEncode.Instance.updateDescription("\n" + preStr + "完成加密.");
        }

        private void zipOutPutResource()
        {
            FileEncode.Instance.updateDescription("\n开始压缩文件:");
            string outFileFullName = "";
            if (System.IO.Directory.Exists(szResourceOutPath))
            {
                //add to zip
                string executeFilePath = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
                executeFilePath = System.IO.Path.GetDirectoryName(executeFilePath);
                executeFilePath = executeFilePath + @"\WinRAR";
                outFileFullName = string.Format(@"{0}\{1}-{2}.zip", szDifferentOutPath, szLastVersion, PackageSubVM.Instance.Version);
                Process p = new Process();
                p.StartInfo.FileName = executeFilePath;
                p.StartInfo.Arguments = string.Format(@"m -r -afzip -ed -m3 -ep1 {0} {1}", outFileFullName, szResourceOutPath + @"\*");
                p.StartInfo.CreateNoWindow = true;
                p.StartInfo.RedirectStandardInput = true;
                p.StartInfo.RedirectStandardError = false;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.ErrorDialog = false;
                p.Start();
                while (!p.HasExited)
                {
                    p.WaitForExit();
                }
                p.Close();
                p.Dispose();
                System.IO.Directory.Delete(szResourceOutPath, true);
            }
            else
            {
                FileEncode.Instance.updateDescription("\n没有文件.:");
            }
            FileEncode.Instance.updateDescription("\n压缩文件完成:" + outFileFullName);
        }

        private void saveCurrentVersion()
        {
            // new: save version to file
            string content = "";
            if (System.IO.File.Exists(PackageSubVM.Instance.OutPath + @"\versions"))
            {
                StreamReader sr = new StreamReader(PackageSubVM.Instance.OutPath + @"\versions");
                while (sr.Peek() > 0)
                {
                    string line = sr.ReadLine();
                    if (!line.Contains(PackageSubVM.Instance.Version))
                    {
                        content += line + "\n";
                    }
                    else
                    {
                        MessageBox.Show("注意, 这是重复的版本号!!!");
                    }
                }
                sr.Close();
            }
            else
            {
                FileStream file = System.IO.File.Create(PackageSubVM.Instance.OutPath + @"\versions");
                file.Close();
            }

            using (FileStream fs = new FileStream(PackageSubVM.Instance.OutPath + @"\versions", FileMode.Truncate, FileAccess.Write))
            {
                using (StreamWriter sw = new StreamWriter(fs, Encoding.UTF8))
                {
                    string outString = "version:" + PackageSubVM.Instance.Version;
                    if (PackageSubVM.Instance.RemoveMEDebug)
                    {
                        outString += "," + "RemoveMEDebug";
                    }
                    //                     if (window.removeAll.IsChecked == true)
                    //                     {
                    //                         outString += "," + "RemoveAll";
                    //                     }
                    if (PackageSubVM.Instance.NeedReInstall == true)
                    {
                        outString += "," + "NeedReInstall:" + PackageSubVM.Instance.ReInstallURL + " ";
                    }
                    sw.Write(content + outString + ";\n");
                }
            }
        }
        
        #endregion
    }
}
