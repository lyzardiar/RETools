﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DragAndRun.ViewModule
{
    class GlobalVM
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                PropertyChangedEventArgs e = new PropertyChangedEventArgs(propertyName);
                this.PropertyChanged(this, e);
            }
        }
        private static GlobalVM _instance;
        public static GlobalVM Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new GlobalVM();
                return _instance;
            }
        }

        private bool _encodeAndroid;
        public bool EncodeAndroid
        {
            get { return _encodeAndroid; }
            set { _encodeAndroid = value; OnPropertyChanged("EncodeAndroid"); }
        }
        
        public enum PackType
        {
            None,
            Pack_All,
            Pack_Sub,
        }
        private PackType _type;
        public PackType Type
        {
            get { return _type; }
            set { _type = value; }
        }

        private string _cndUserName = "sqsj";
        public string CDNUserName
        {
            get { return _cndUserName; }
            set { _cndUserName = value; OnPropertyChanged("CDNUserName"); }
        }

        private string _cdnPassword = "Abc@123";
        public string CDNPassword
        {
            get { return _cdnPassword; }
            set { _cdnPassword = value; OnPropertyChanged("CDNPassword"); }
        }
    }
}
